import { LightningElement,api } from 'lwc';
export default class GetNullValue extends LightningElement {
    @api errorMessage;

}