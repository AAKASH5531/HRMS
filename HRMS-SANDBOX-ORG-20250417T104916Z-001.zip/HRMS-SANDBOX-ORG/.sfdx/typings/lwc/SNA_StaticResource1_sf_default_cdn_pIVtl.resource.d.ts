declare module "@salesforce/resourceUrl/SNA_StaticResource1_sf_default_cdn_pIVtl" {
    var SNA_StaticResource1_sf_default_cdn_pIVtl: string;
    export default SNA_StaticResource1_sf_default_cdn_pIVtl;
}