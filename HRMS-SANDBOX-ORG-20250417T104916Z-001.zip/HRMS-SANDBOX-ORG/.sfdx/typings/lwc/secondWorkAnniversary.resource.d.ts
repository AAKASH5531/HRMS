declare module "@salesforce/resourceUrl/secondWorkAnniversary" {
    var secondWorkAnniversary: string;
    export default secondWorkAnniversary;
}