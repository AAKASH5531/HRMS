declare module "@salesforce/resourceUrl/Employee_Status" {
    var Employee_Status: string;
    export default Employee_Status;
}