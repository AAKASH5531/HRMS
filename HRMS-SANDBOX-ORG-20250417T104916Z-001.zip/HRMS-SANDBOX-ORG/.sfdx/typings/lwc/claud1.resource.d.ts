declare module "@salesforce/resourceUrl/claud1" {
    var claud1: string;
    export default claud1;
}