declare module "@salesforce/resourceUrl/thirdWorkAnniversary" {
    var thirdWorkAnniversary: string;
    export default thirdWorkAnniversary;
}