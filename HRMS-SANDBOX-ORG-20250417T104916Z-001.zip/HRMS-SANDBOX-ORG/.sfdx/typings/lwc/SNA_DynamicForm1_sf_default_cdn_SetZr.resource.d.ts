declare module "@salesforce/resourceUrl/SNA_DynamicForm1_sf_default_cdn_SetZr" {
    var SNA_DynamicForm1_sf_default_cdn_SetZr: string;
    export default SNA_DynamicForm1_sf_default_cdn_SetZr;
}