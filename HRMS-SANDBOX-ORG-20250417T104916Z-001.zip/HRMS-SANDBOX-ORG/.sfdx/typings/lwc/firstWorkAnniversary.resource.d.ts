declare module "@salesforce/resourceUrl/firstWorkAnniversary" {
    var firstWorkAnniversary: string;
    export default firstWorkAnniversary;
}