declare module "@salesforce/resourceUrl/Birthday" {
    var Birthday: string;
    export default Birthday;
}