declare module "@salesforce/resourceUrl/claud2" {
    var claud2: string;
    export default claud2;
}